import os

class Config(object):
    FLASK_APP = "run.py"
    FLASK_ENV = "development"